import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ForgetpasswordsuccessPage } from './forgetpasswordsuccess';

@NgModule({
  declarations: [
    ForgetpasswordsuccessPage,
  ],
  imports: [
    IonicPageModule.forChild(ForgetpasswordsuccessPage),
  ],
})
export class ForgetpasswordsuccessPageModule {}
